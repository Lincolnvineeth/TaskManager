# TaskOrganizer

A collaborative task management solution.  
Frontend: Vue.js + Tailwind CSS  
Backend: Flask (Python)

## Getting Started

- See `frontend/public/index.html` for UI prototype.
- Backend: `cd backend && python run.py`
- Frontend: `cd frontend && npm install && npm run dev`