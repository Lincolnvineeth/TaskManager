module.exports = {
  content: ["./src/**/*.{vue,js,ts}", "./public/index.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}